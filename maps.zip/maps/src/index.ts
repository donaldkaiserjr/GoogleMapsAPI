import { User } from './User';
import { Company } from './Company';
import { CustomMap } from './CustomMap';

'use strict';
// go to http://console.developers.google.com   google maps, then generate an API key
// npm install @types/googlemaps




const user = new User();
const company = new Company()
const customMap = new CustomMap('map');

customMap.addMarker(user);
customMap.addMarker(company)



