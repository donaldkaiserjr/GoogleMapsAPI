import faker from 'faker';
import { Mappable } from './CustomMap';
'use strict';


export class User implements Mappable {     // exporting allows the class to be available in another file
  name: string;
  location: {
      lat: number;
      lng: number;
  };

  color: string = 'red';

  constructor() {
      this.name = faker.name.firstName();   // in the definition file index.d.ts or on Faker website you'll see firstName() and other properties. 
      this.location = {
          lat: parseFloat(faker.address.latitude()),  // in the def file, the lat and lng are set to strings, which is an oversight by the Faker folks. parseFloat converts our number to string
          lng: parseFloat(faker.address.longitude())
      };

  }
  markerContent(): string{
      return `User Name: ${this.name}`
  }
}


